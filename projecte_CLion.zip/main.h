/*
 * main.h
 *
 *  Created on: 19 mar. 2020
 *      Author: droma
 */

#ifndef MAIN_H_
#define MAIN_H_

#define DEBUG_LEVEL 3

#endif /* MAIN_H_ */
